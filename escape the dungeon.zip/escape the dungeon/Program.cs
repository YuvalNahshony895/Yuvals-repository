﻿using System;

class Program
{
  
    public static void Main()
    {
        Game game = new Game();
        game.Start();
    }
}


    
    


